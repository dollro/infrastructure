# Agentic AI Development Skill

## Overview
This guide establishes the engineering standard for building **production-grade agentic AI systems** by fusing three best-of-breed frameworks:

| Framework | Role | Responsibility |
|-----------|------|----------------|
| **LangGraph** | Orchestrator | Stateful workflow control, cyclic graphs, persistence, HITL |
| **Pydantic AI** | Single-Agent Executor | Type-safe agents with dependency injection, structured outputs |
| **CrewAI** | Multi-Agent Teams | Role-based collaborative agents for complex, delegated tasks |

## When to Use This Skill
- Building multi-agent orchestration systems
- Implementing type-safe AI agents
- Designing LangGraph workflows
- CrewAI team configurations

---

## 1. Architectural Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    LangGraph (Control Plane)                    │
│  ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐  │
│  │  Router  │───▶│ Pydantic │───▶│  CrewAI  │───▶│ Validator│  │
│  │   Node   │    │ AI Node  │    │   Node   │    │   Node   │  │
│  └──────────┘    └──────────┘    └──────────┘    └──────────┘  │
│        │              │               │               │         │
│        └──────────────┴───────────────┴───────────────┘         │
│                    Shared Typed State (Pydantic)                │
└─────────────────────────────────────────────────────────────────┘
```

- **LangGraph** handles the *how*: workflow orchestration, conditional routing, persistence
- **Pydantic AI** handles *type-safe execution*: single agents with validation guarantees
- **CrewAI** handles the *who*: multi-agent teams with role-based collaboration



### 1.1 The Paradigm: Deterministic Harness Around Probabilistic Engines

The fundamental challenge in agentic AI is building **reliable, deterministic applications** using **inherently non-deterministic LLMs**. This architecture solves it through:

1. **LangGraph**: The "nervous system" - models cognitive architecture as a Directed Cyclic Graph (DCG)
2. **Pydantic**: The "immune system" - enforces data integrity, rejects hallucinations
3. **CrewAI**: The "team dynamics" - coordinates specialized agents with clear roles

### 1.2 Component Responsibilities

```python
# Table 1: Architectural Roles in the Unified Stack
"""
┌─────────────────┬─────────────┬────────────────────────────────────────┬─────────────────────────┐
│ Arch. Layer     │ Component   │ Responsibility                         │ Failure Mode Handling   │
├─────────────────┼─────────────┼────────────────────────────────────────┼─────────────────────────┤
│ Control Flow    │ LangGraph   │ Orchestrates sequence, manages loops,  │ Routes to retry/end     │
│                 │             │ branches, persistence                  │ based on edge logic     │
├─────────────────┼─────────────┼────────────────────────────────────────┼─────────────────────────┤
│ Data Integrity  │ Pydantic    │ Defines state structure, validates     │ Raises ValidationError  │
│                 │             │ inputs/outputs, serializes data        │ to trigger retry loop   │
├─────────────────┼─────────────┼────────────────────────────────────────┼─────────────────────────┤
│ Single-Agent    │ Pydantic AI │ Type-safe agent execution with DI,     │ Structured output       │
│ Execution       │             │ tool handling, structured outputs      │ validation              │
├─────────────────┼─────────────┼────────────────────────────────────────┼─────────────────────────┤
│ Multi-Agent     │ CrewAI      │ Role-based teams, task delegation,     │ Crew-level retry,       │
│ Collaboration   │             │ collaborative problem solving          │ manager escalation      │
├─────────────────┼─────────────┼────────────────────────────────────────┼─────────────────────────┤
│ Cognition       │ LLM         │ Generates content, reasoning traces,   │ Raw material shaped     │
│                 │             │ tool calls                             │ by Pydantic validation  │
├─────────────────┼─────────────┼────────────────────────────────────────┼─────────────────────────┤
│ Persistence     │ Checkpointer│ Saves graph state at every step,       │ Ensures state recovery  │
│                 │             │ enables time-travel and HITL           │ (handle serialization)  │
└─────────────────┴─────────────┴────────────────────────────────────────┴─────────────────────────┘
"""
```

---

## 2. The Three-Framework Integration Pattern

### 2.1 Core Integration Philosophy

The integration follows the **Adapter Pattern**: LangGraph manages the workflow while Pydantic AI and CrewAI agents are wrapped as specialized nodes.

```python
"""
Integration Pattern Overview:

LangGraph Node Types:
├── Standard Nodes      → Pure functions for routing, validation, preprocessing
├── Pydantic AI Nodes   → Single-agent tasks requiring type safety
└── CrewAI Nodes        → Multi-agent collaborative tasks

Node Selection Criteria:
┌─────────────────────────────────────────────────────────────────────────┐
│ Task Characteristic              │ Recommended Node Type               │
├──────────────────────────────────┼─────────────────────────────────────┤
│ Simple validation/routing        │ Standard LangGraph function         │
│ Single-agent with structured out │ Pydantic AI Adapter Node            │
│ Multi-agent collaboration        │ CrewAI Adapter Node                 │
│ Human approval required          │ LangGraph interrupt + validation    │
└─────────────────────────────────────────────────────────────────────────┘
"""
```

### 2.2 Typical Project Structure

Organize by **pipeline phase**, not by framework. Each phase file contains the framework-specific code it needs (Pydantic AI agent, CrewAI crew, etc.). This keeps related code together and avoids empty abstraction layers.

```
project/
├── pyproject.toml
├── pipeline/
│   ├── __init__.py
│   ├── orchestrator.py        # Entry point — run_pipeline() wires extract → graph → apply
│   ├── graph.py               # LangGraph StateGraph builder + node adapters
│   ├── state.py               # TypedDict graph state
│   ├── schemas.py             # Pydantic output models (research + domain schemas)
│   ├── models.py              # LLM factory functions (get_model, get_crewai_llm)
│   ├── research.py            # Pydantic AI research agents + LangGraph adapter nodes
│   ├── tracing.py             # Langfuse/OTel initialization + callback factory
│   ├── handlers/              # Domain I/O adapters (extract/apply pattern)
│   │   ├── __init__.py
│   │   ├── base.py            # BaseHandler ABC
│   │   └── pdf.py             # Format-specific handler
│   ├── interview/             # Multi-agent refinement subpackage
│   │   ├── __init__.py
│   │   ├── schemas.py         # Internal Pydantic schemas (expert, moderator, writer)
│   │   ├── prompts.py         # Prompt builders for experts, moderator, writer
│   │   ├── crews.py           # CrewAI crew builders + agent templates
│   │   ├── memory.py          # CrewAI scoped memory factory
│   │   └── loop.py            # LangGraph refinement subgraph
│   └── prompts/
│       └── research.py        # System prompts for research agents
├── tests/
│   ├── unit/
│   ├── integration/
│   └── conftest.py
└── main.py
```

### 2.3 Dependencies

```toml
# pyproject.toml
# CRITICAL: Install order matters due to OTel version pinning.
# CrewAI pins opentelemetry-api~=1.34.0; if Langfuse installs first,
# it picks 1.39.x which breaks CrewAI. Use a lockfile or install order:
# crewai → langfuse → langchain → pydantic-ai
[project]
dependencies = [
    "langgraph>=1.0.0",
    "langchain>=1.2.0",            # Full langchain required for Langfuse CallbackHandler
    "pydantic>=2.5",
    "pydantic-ai[openrouter]>=0.1.0",  # Use [openrouter] extra for OpenRouter setups
    "crewai>=1.10.0",
    "langfuse>=3.0.0",
    "openinference-instrumentation-crewai>=0.1.0",  # CrewAI → OTel bridge
]

[project.optional-dependencies]
dev = [
    "pytest>=8.0",
    "pytest-asyncio>=0.23",
    "dirty-equals>=0.8",
]
```

### 2.4 Model Factory Pattern

**Best Practice**: Never hardcode model identifiers in Agent definitions. Use a factory that resolves models from configuration at runtime.

```python
# src/utils/model_factory.py
"""
Centralized model factory for all frameworks.

CRITICAL: Agents are defined WITHOUT a model. The model is injected
at invocation time, enabling:
- Environment-driven model selection (dev vs prod)
- Tiered routing (cheap model for routing, expensive for generation)
- Easy testing (swap to TestModel without touching agent code)
"""
from functools import lru_cache
from django.conf import settings  # Or your config system
from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.providers.openai import OpenAIProvider
from crewai import LLM


# Model tiers — map logical roles to concrete model identifiers
MODEL_TIERS = {
    "brain": "anthropic/claude-opus-4-6",       # Complex reasoning
    "workhorse": "anthropic/claude-sonnet-4-6",  # Balanced
    "bolt": "anthropic/claude-haiku-4-5-20251001",  # Fast/cheap
}


def _get_api_key() -> str:
    """Resolve API key from settings with env fallback."""
    return getattr(settings, "LLM_API_KEY", None) or os.environ.get("OPENROUTER_API_KEY", "")


def _get_base_url() -> str:
    """Resolve base URL from settings."""
    return getattr(settings, "LLM_BASE_URL", "https://openrouter.ai/api/v1")


def _get_provider() -> OpenAIProvider:
    """Shared provider instance for all Pydantic AI models."""
    return OpenAIProvider(base_url=_get_base_url(), api_key=_get_api_key())


def get_model(role: str = "workhorse") -> OpenAIChatModel:
    """
    Returns a Pydantic AI model for the given role.

    Usage in nodes:
        result = await agent.run(prompt, model=get_model("brain"), deps=deps)
    """
    model_name = getattr(settings, f"LLM_{role.upper()}", MODEL_TIERS.get(role, MODEL_TIERS["workhorse"]))

    return OpenAIChatModel(
        model_name,
        provider=_get_provider(),
    )


def get_crewai_llm(role: str = "brain") -> LLM:
    """
    Returns a CrewAI LLM for the given role.

    Usage in crews:
        Agent(role=..., llm=get_crewai_llm("brain"))
    """
    model_name = getattr(settings, f"LLM_{role.upper()}", MODEL_TIERS.get(role, MODEL_TIERS["brain"]))
    return LLM(
        model=f"openai/{model_name}",
        api_key=_get_api_key(),
        base_url=_get_base_url(),
    )
```

---

## 3. State Management with Pydantic

### 3.1 The Hybrid State Pattern (CRITICAL)

**Best Practice**: Use `TypedDict(total=False)` for the graph envelope and `Pydantic BaseModel` for complex payloads (output schemas, inter-agent contracts). The `total=False` makes all fields optional — nodes return only the fields they touch.

**Two archetypes** exist. Choose based on your pipeline:

| Archetype | Use when | `messages` field? |
|-|-|-|
| **Task Pipeline** (default) | Batch processing, document pipelines, research → synthesis | No. Pure domain fields. |
| **Conversational Agent** | Chatbots, interactive assistants, HITL-heavy flows | Yes. `Annotated[list[BaseMessage], operator.add]` |

Most production pipelines are task pipelines. Use message history only for conversational flows.

#### 3.1.1 Domain Models (Pydantic BaseModel)

```python
# src/state/models.py
"""
Domain entities as strict Pydantic models.
These represent the business objects flowing through the graph.
"""
from pydantic import BaseModel, Field


class ResearchOutput(BaseModel):
    """Validated research output from agents."""
    summary: str = Field(..., min_length=50)
    confidence: float = Field(ge=0.0, le=1.0)
    sources: list[str] = Field(default_factory=list)
    metadata: dict = Field(default_factory=dict)


class Section(BaseModel):
    """A unit of work identified for processing."""
    id: str = Field(description="Opaque handler-assigned identifier")
    original_text: str = Field(description="The text content to process")
    context: str = Field(default="", description="Surrounding context for the LLM")
    metadata: dict = Field(default_factory=dict, description="Handler-private data, stripped before LLM prompts")


class SectionOptimized(BaseModel):
    """A processed section returned by the optimization node."""
    id: str = Field(description="Echoed from Section.id")
    original_text: str = Field(description="Original text (echoed back for diff)")
    optimized_text: str = Field(description="LLM-rewritten text")
    reasoning: str = Field(description="Why this change was made")
```

#### 3.1.2 Graph State (Task Pipeline — Default)

```python
# src/state/graph_state.py
"""
The Graph State using TypedDict as the envelope.

CRITICAL: Use total=False so all fields are optional.
Nodes return ONLY the fields they update. LangGraph merges them.
Use Annotated reducers for fields written by parallel branches.
"""
from typing import Annotated
from typing_extensions import TypedDict
import operator


def _merge_dicts(left: dict, right: dict) -> dict:
    """Shallow merge reducer for dict fields."""
    merged = left.copy()
    merged.update(right)
    return merged


class PipelineState(TypedDict, total=False):
    """
    Central state for a task pipeline.

    Design Principles:
    1. total=False — nodes return only their fields, no verbose initialization needed
    2. Pydantic models for complex values (validation at boundaries)
    3. Annotated with reducer for fields written by parallel branches
    4. No LangChain messages — pure domain fields
    """

    # === Input (set before graph.invoke) ===
    mode: str
    input_data: str | None
    additional_instructions: str | None

    # === Domain Objects (serialized as dicts for LangGraph compatibility) ===
    sections: list[dict]              # list of Section.model_dump()
    sections_optimized: list[dict]    # list of SectionOptimized.model_dump()

    # === Research Intermediate ===
    research_a: dict | None           # e.g. CompanyResearch.model_dump()
    research_b: dict | None           # e.g. StakeholderResearch.model_dump()
    research_summary: str

    # === Pipeline Tracking (cumulative across parallel nodes) ===
    # Annotated reducers allow parallel branches to write concurrently
    # without INVALID_CONCURRENT_GRAPH_UPDATE errors.
    cumulative_tokens: Annotated[int, operator.add]
    phase_token_usage: Annotated[dict, _merge_dicts]
    phase_reasonings: Annotated[list[dict], operator.add]
```

#### 3.1.3 Conversational Variant (when you need message history)

```python
# Only use this pattern for chatbot/interactive flows
from langchain_core.messages import BaseMessage

class ConversationalState(TypedDict, total=False):
    """State for conversational agents (chatbots, HITL flows)."""
    messages: Annotated[list[BaseMessage], operator.add]
    # ... plus your domain fields
```

---

## 4. LangGraph Orchestration Layer

### 4.1 Graph Definition

```python
# src/graph/workflow.py
"""
The LangGraph workflow definition.
This is the control plane that orchestrates all agents.
"""
from typing import Literal
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.checkpoint.serde.jsonplus import JsonPlusSerializer

from pipeline.state import PipelineState
from pipeline.nodes import (
    router_node,
    pydantic_ai_research_node,
    pydantic_ai_analyzer_node,
    crewai_content_crew_node,
    validator_node,
    fixer_node,
    human_approval_node,
)


def create_workflow(checkpointer=None) -> StateGraph:
    """
    Creates the LangGraph workflow with all nodes and edges.
    
    Graph Topology:
    
    [Entry] ──► [Router] ──┬──► [PydanticAI Research] ──► [Validator] ──┬──► [Router]
                           │                                            │
                           ├──► [PydanticAI Analyzer] ──► [Validator] ──┤
                           │                                            │
                           ├──► [CrewAI Content Team] ──► [Validator] ──┤
                           │                                            │
                           ├──► [Human Approval] ─────────────────────►─┤
                           │                                            │
                           └──► [END]                    [Fixer] ◄──────┘
                                                             │
                                                             ▼
                                                    (loops back to source)
    """
    
    # Initialize the graph with our typed state
    workflow = StateGraph(PipelineState)
    
    # === Add Nodes ===
    workflow.add_node("router", router_node)
    workflow.add_node("research", pydantic_ai_research_node)
    workflow.add_node("analyzer", pydantic_ai_analyzer_node)
    workflow.add_node("content_crew", crewai_content_crew_node)
    workflow.add_node("validator", validator_node)
    workflow.add_node("fixer", fixer_node)
    workflow.add_node("human_approval", human_approval_node)
    
    # === Set Entry Point ===
    workflow.set_entry_point("router")
    
    # === Add Conditional Edges from Router ===
    workflow.add_conditional_edges(
        "router",
        route_after_router,
        {
            "research": "research",
            "analyze": "analyzer",
            "crew_task": "content_crew",
            "human_review": "human_approval",
            "end": END,
        }
    )
    
    # === Add Edges from Agent Nodes to Validator ===
    workflow.add_edge("research", "validator")
    workflow.add_edge("analyzer", "validator")
    workflow.add_edge("content_crew", "validator")
    
    # === Add Conditional Edges from Validator ===
    workflow.add_conditional_edges(
        "validator",
        route_after_validation,
        {
            "success": "router",
            "retry": "fixer",
            "fatal": END,
        }
    )
    
    # === Fixer loops back to appropriate node ===
    workflow.add_conditional_edges(
        "fixer",
        route_after_fixer,
        {
            "research": "research",
            "analyze": "analyzer",
            "crew_task": "content_crew",
        }
    )
    
    # === Human Approval routes back to router ===
    workflow.add_edge("human_approval", "router")
    
    return workflow


def route_after_router(state: PipelineState) -> str:
    """Determines which node to execute based on state."""
    return state.get("next_action", "end")


def route_after_validation(state: PipelineState) -> Literal["success", "retry", "fatal"]:
    """Routes based on validation results."""
    if state.get("last_error") is None:
        return "success"
    
    if state.get("retry_count", 0) >= state.get("max_retries", 3):
        return "fatal"
    
    return "retry"


def route_after_fixer(state: PipelineState) -> str:
    """Routes fixer output back to the appropriate agent."""
    return state.get("current_step", "research")


def compile_graph(use_persistence: bool = True):
    """
    Compiles the graph with optional persistence.
    
    SECURITY NOTE: Always disable pickle fallback in production.
    """
    workflow = create_workflow()
    
    if use_persistence:
        # CRITICAL: Disable pickle for security
        strict_serializer = JsonPlusSerializer(pickle_fallback=False)
        checkpointer = InMemorySaver(serde=strict_serializer)
        return workflow.compile(checkpointer=checkpointer)
    
    return workflow.compile()
```

### 4.2 Routing Patterns

Routers can be **heuristic** (fast, deterministic) or **LLM-based** (flexible). Prefer heuristic routing when conditions are well-defined; fall back to LLM routing for ambiguous decisions.

```python
# pipeline/graph.py (routing functions)
"""
Routing decisions as pure functions.
Best practice: heuristic first, LLM only when needed.
"""


def route_after_research(state: PipelineState) -> str:
    """Heuristic routing — fast, deterministic, no LLM cost."""
    if state.get("research_a") and state.get("research_b"):
        return "merge_research"
    return "continue_research"


def route_after_validation(state: PipelineState) -> str:
    """Conditional edge: check convergence conditions."""
    if state.get("all_sections_resolved"):
        return "end"
    if state.get("diminishing_returns"):
        return "end"
    if state.get("current_round", 0) >= state.get("max_rounds", 3):
        return "end"
    return "continue"
```

For LLM-based routing (when heuristic logic is insufficient):

```python
from pydantic import BaseModel
from pydantic_ai import Agent


class RouterDecision(BaseModel):
    """Type-safe routing using Literal to constrain valid choices."""
    next_action: str  # Constrain with Literal for your specific graph
    reasoning: str


router_agent = Agent(output_type=RouterDecision)

def llm_router_node(state: PipelineState) -> dict:
    """LLM-based routing for ambiguous decisions."""
    result = router_agent.run_sync(
        f"Given the current state, decide the next action...",
        model=get_model("bolt"),  # Use cheap model for routing
    )
    return {"next_action": result.output.next_action}
```

---

## 5. Pydantic AI Node Implementation

### 5.1 The Adapter Pattern

```python
# src/nodes/pydantic_ai/research_agent.py
"""
Pydantic AI Research Agent wrapped as a LangGraph node.

This demonstrates the Adapter Pattern:
- LangGraph manages workflow and state
- Pydantic AI manages agent execution with type safety
"""
from uuid import uuid4
from datetime import datetime
from pydantic_ai import Agent, RunContext
from pydantic import BaseModel, Field
from dataclasses import dataclass

from pipeline.state import PipelineState
from pipeline.schemas import ResearchArtifact
from pipeline.utils.serialization import inflate_model, deflate_model


# === Pydantic AI Agent Definition ===

@dataclass
class ResearchDependencies:
    """
    Dependencies injected into the Pydantic AI agent.
    This enables testability and configuration.
    """
    search_api_key: str
    max_results: int = 10


class ResearchOutput(BaseModel):
    """Structured output from the research agent."""
    findings: list[str] = Field(..., min_length=1)
    sources: list[str]
    confidence: float = Field(ge=0.0, le=1.0)
    suggested_followup: str | None = None


# Create the Pydantic AI agent — model is NOT specified here.
# The model is passed at invocation time via .run() / .run_sync(),
# enabling environment-driven model selection and easier testing.
research_agent = Agent(
    deps_type=ResearchDependencies,
    output_type=ResearchOutput,
    system_prompt="""You are a senior research analyst. Your task is to:
    1. Analyze the user's query
    2. Search for relevant information
    3. Synthesize findings with source attribution
    4. Provide confidence scores for your findings

    Always cite your sources and be explicit about uncertainty.
    """
)


@research_agent.tool
async def web_search(ctx: RunContext[ResearchDependencies], query: str) -> str:
    """Search the web for information."""
    # In production, this would call an actual search API
    # Here we demonstrate the pattern
    return f"Search results for: {query} (using key: {ctx.deps.search_api_key[:4]}...)"


# === LangGraph Adapter Node ===

async def pydantic_ai_research_node(state: PipelineState) -> dict:
    """
    Adapts LangGraph state to Pydantic AI context and back.
    
    This node:
    1. Extracts context from LangGraph state
    2. Runs the Pydantic AI agent
    3. Maps results back to LangGraph state format
    
    CRITICAL: Implements Inflate/Deflate pattern for serialization safety.
    """
    
    # === EXTRACT CONTEXT FROM STATE ===
    messages = state.get("messages", [])
    last_message = messages[-1].content if messages else ""
    
    # Inflate existing memory if present
    raw_memory = state.get("memory")
    if raw_memory and isinstance(raw_memory, dict):
        from pipeline.schemas import AgentMemory
        memory = AgentMemory.model_validate(raw_memory)
    else:
        memory = None
    
    # Build query with context
    query = last_message
    if memory and memory.short_term_context:
        query = f"Context: {memory.short_term_context}\n\nQuery: {last_message}"
    
    # === RUN PYDANTIC AI AGENT ===
    deps = ResearchDependencies(
        search_api_key="sk-xxx",  # In production, from config
        max_results=10
    )

    try:
        # Model is passed at invocation, not at Agent definition.
        # This allows env-driven model selection (e.g. tier-based routing).
        result = await research_agent.run(
            query,
            model=get_model("research"),  # From your model factory
            deps=deps,
        )
        
        # Create structured artifact
        artifact = ResearchArtifact(
            artifact_id=uuid4(),
            url="https://research.example.com/result",  # Would come from actual search
            summary="\n".join(result.output.findings),
            relevance_score=result.output.confidence,
            source_type="web",
            timestamp=datetime.now(),
        )
        
        # === DEFLATE FOR SAFE SERIALIZATION ===
        return {
            "artifacts": [artifact.model_dump(mode='json')],
            "current_step": "research",
            "last_error": None,
        }
        
    except Exception as e:
        return {
            "last_error": str(e),
            "current_step": "research",
            "retry_count": state.get("retry_count", 0) + 1,
        }
```

### 5.2 Analyzer Agent (Second Pydantic AI Node)

```python
# src/nodes/pydantic_ai/analyzer_agent.py
"""
Pydantic AI Analyzer Agent - demonstrates processing artifacts from previous nodes.
"""
from uuid import uuid4
from pydantic_ai import Agent
from pydantic import BaseModel, Field

from pipeline.state import PipelineState
from pipeline.schemas import ResearchArtifact, TaskResult


class AnalysisOutput(BaseModel):
    """Structured analysis output."""
    key_insights: list[str] = Field(..., min_length=1)
    risk_factors: list[str] = Field(default_factory=list)
    recommendations: list[str] = Field(..., min_length=1)
    confidence: float = Field(ge=0.0, le=1.0)
    executive_summary: str = Field(..., min_length=100)


analyzer_agent = Agent(
    output_type=AnalysisOutput,
    system_prompt="""You are a senior analyst. Given research artifacts:
    1. Synthesize key insights
    2. Identify risk factors
    3. Provide actionable recommendations
    4. Write an executive summary
    """
)


async def pydantic_ai_analyzer_node(state: PipelineState) -> dict:
    """
    Analyzes accumulated research artifacts.
    
    Demonstrates:
    - Inflating Pydantic models from state
    - Processing multiple artifacts
    - Creating validated task results
    """
    
    # === INFLATE ARTIFACTS ===
    raw_artifacts = state.get("artifacts", [])
    artifacts = []
    for raw in raw_artifacts:
        if isinstance(raw, dict):
            artifacts.append(ResearchArtifact.model_validate(raw))
        elif isinstance(raw, ResearchArtifact):
            artifacts.append(raw)
    
    if not artifacts:
        return {
            "last_error": "No artifacts to analyze",
            "current_step": "analyzer",
        }
    
    # Build analysis prompt
    artifact_summaries = "\n\n".join([
        f"Source: {a.url}\nRelevance: {a.relevance_score}\nSummary: {a.summary}"
        for a in artifacts
    ])
    
    try:
        result = await analyzer_agent.run(
            f"Analyze the following research:\n\n{artifact_summaries}",
            model=get_model("analysis"),
        )
        
        # Create task result
        task_result = TaskResult(
            task_id=uuid4(),
            status="completed",
            output=result.output.executive_summary,
            confidence=result.output.confidence,
            metadata={
                "insights_count": len(result.output.key_insights),
                "risks_count": len(result.output.risk_factors),
                "recommendations": result.output.recommendations,
            }
        )
        
        return {
            "task_results": [task_result.model_dump(mode='json')],
            "current_step": "analyzer",
            "last_error": None,
        }
        
    except Exception as e:
        return {
            "last_error": str(e),
            "current_step": "analyzer",
            "retry_count": state.get("retry_count", 0) + 1,
        }
```

---

## 5b. Domain I/O Handler Pattern (extract/apply)

### The Extract/Apply Pattern

A production pipeline often needs to handle multiple input formats (PDF, DOCX, Typst, Markdown) while keeping the AI pipeline format-agnostic. The **Handler pattern** decouples domain-specific I/O from the AI graph:

```
handler.extract() → [AI Pipeline (LangGraph graph)] → handler.apply()
```

Handlers produce `Section` dicts in `extract()` and consume `SectionOptimized` dicts in `apply()`. The graph never knows what format it's working with.

```python
# pipeline/handlers/base.py
"""
Base handler ABC. Each format implements extract() and apply().
The AI pipeline is format-agnostic — it only sees Section/SectionOptimized.
"""
from abc import ABC, abstractmethod
from typing import Any


class BaseHandler(ABC):
    @abstractmethod
    def extract(self) -> dict[str, Any]:
        """Extract domain data → state fields for the graph.
        Returns dict with 'sections' (list of Section dicts), plus any
        format-specific state fields (e.g. 'template_context')."""

    @abstractmethod
    def apply(self, sections_optimized: list[dict[str, Any]]) -> dict[str, Any]:
        """Post-process optimized sections → final domain output.
        Consumes SectionOptimized dicts from the graph and produces
        the final result in the original format."""
```

```python
# pipeline/handlers/pdf.py
"""Example: PDF handler extracts highlighted sections, returns read-only results."""
from pipeline.handlers.base import BaseHandler
from pipeline.schemas import Section


class PdfHandler(BaseHandler):
    def __init__(self, pdf_paths: list[str]):
        self.pdf_paths = pdf_paths

    def extract(self) -> dict:
        sections = []
        for path in self.pdf_paths:
            highlights = extract_pdf_highlights(path)  # Your PDF library
            for h in highlights:
                sections.append(Section(
                    id=f"{path}:{h.page}:{h.index}",
                    original_text=h.text,
                    context=h.surrounding_text,
                    metadata={"page": h.page, "path": path},  # Opaque to LLM
                ).model_dump())
        return {"sections": sections}

    def apply(self, sections_optimized: list[dict]) -> dict:
        # PDF is read-only — just return suggestions for UI
        return {"suggestions": sections_optimized}
```

```python
# pipeline/orchestrator.py
"""
The orchestrator wires handler ↔ graph ↔ handler.
The graph is IDENTICAL regardless of format.
"""
def run_pipeline(handler: BaseHandler, graph, session_id: str) -> dict:
    # 1. Extract domain data → graph state
    state_input = handler.extract()

    # 2. Run format-agnostic AI pipeline
    result = graph.invoke(state_input, config={"callbacks": [...]})

    # 3. Apply optimized sections → domain output
    return handler.apply(result.get("sections_optimized", []))
```

**Key design benefits:**
- **Adding a new format** = one new handler class. No graph changes.
- **The `metadata` field on `Section`** is opaque — stripped before LLM prompts, carried through untouched so handlers can relocate sections in the original document during `apply()`.
- **Unified section contract** (`Section` / `SectionOptimized`) is the stable API between handlers and the AI pipeline.

---

## 6. CrewAI Node Implementation

### 6.1 Agent Templates and Per-Round Cloning

**CRITICAL**: CrewAI `Agent` objects mutate internal state during `kickoff()`. Never reuse agents across rounds. Define immutable templates and clone fresh agents per round.

```python
# pipeline/interview/crews.py
"""
CrewAI Agent Templates and Crew Builders.

Pattern: Frozen dataclass templates → fresh Agent clones per round.
This is MANDATORY because CrewAI mutates Agent internals during execution.
"""
from dataclasses import dataclass
from crewai import Agent
from pipeline.models import get_crewai_llm


@dataclass(frozen=True)
class AgentTemplate:
    """Immutable agent definition. No LLM coupling, no per-run state."""
    role: str
    goal: str
    backstory: str


# Module-level templates — define once, clone per round
expert_ats = AgentTemplate(
    role="ATS & Compliance Specialist",
    goal="Ensure keyword density, formatting compliance, and employment gap handling",
    backstory="You review thousands of CVs annually for ATS optimization...",
)

expert_impact = AgentTemplate(
    role="Technical Impact Assessor",
    goal="Maximize quantified achievements using STAR method, technical depth",
    backstory="You evaluate technical contributions for impact and specificity...",
)

expert_clarity = AgentTemplate(
    role="Communication & Authenticity Auditor",
    goal="Ensure readability, authentic voice, jargon-free clarity",
    backstory="You audit professional documents for clear communication...",
)

moderator = AgentTemplate(
    role="Editorial Chief",
    goal="Resolve conflicting expert feedback into a single coherent revision plan",
    backstory="You synthesize competing perspectives and make editorial decisions...",
)

writer = AgentTemplate(
    role="Professional CV Writer",
    goal="Execute revision instructions with precision and consistency",
    backstory="You apply targeted text revisions while preserving voice...",
)

EXPERT_AGENTS = [expert_ats, expert_impact, expert_clarity]


def _clone_agent(template: AgentTemplate, llm, memory=None) -> Agent:
    """Create a fresh CrewAI Agent from an immutable template."""
    return Agent(
        role=template.role,
        goal=template.goal,
        backstory=template.backstory,
        llm=llm,
        memory=memory,
        verbose=False,
        allow_delegation=False,
    )
```

### 6.2 Per-Round Crew Builder with Structured Output

```python
# pipeline/interview/crews.py (continued)
"""
CRITICAL: Instantiate a fresh Crew every round. CrewAI mutates Crew
during execution. Never reuse Crew objects across iterations.
"""
from crewai import Crew, Task, Process
from pipeline.interview.schemas import ExpertRoundOutput, ModerationResult, WriterRoundOutput
from pipeline.interview.prompts import (
    build_expert_prompt, build_moderator_prompt, build_writer_prompt,
)


def build_round_crew(
    sections: list[dict],
    research_summary: str,
    round_number: int,
    latest_rationale: str = "",
    llm_expert=None,
    llm_moderator=None,
    llm_writer=None,
    memory=None,
) -> Crew:
    """
    Build a fresh Crew for one refinement round.

    Topology (Process.sequential):
    1. 3 Expert tasks (async_execution=True — run in parallel)
    2. Moderator task (context=[expert_tasks] — waits for all experts)
    3. Writer task (context=[moderator_task] — Moderator Shield)

    NOTE on async_execution: Setting True enables parallel expert execution
    but breaks OTel/Langfuse context propagation (ThreadPoolExecutor doesn't
    inherit contextvars). Use False if perfect trace linkage matters more
    than parallelism. For most production pipelines, the performance gain
    from parallel experts outweighs the tracing gap.
    """
    llm_expert = llm_expert or get_crewai_llm("brain")
    llm_moderator = llm_moderator or get_crewai_llm("brain")
    llm_writer = llm_writer or get_crewai_llm("brain")

    # Clone fresh agents for this round
    expert_agents = [_clone_agent(t, llm_expert, memory) for t in EXPERT_AGENTS]
    mod_agent = _clone_agent(moderator, llm_moderator, memory)
    wrt_agent = _clone_agent(writer, llm_writer, memory)

    # Expert tasks — parallel via async_execution
    expert_tasks = [
        Task(
            description=build_expert_prompt(agent.role, sections, research_summary, latest_rationale),
            expected_output="Per-section verdict (APPROVE/REVISE) with feedback",
            agent=agent,
            output_pydantic=ExpertRoundOutput,  # Enforces Pydantic schema
            async_execution=True,
        )
        for agent in expert_agents
    ]

    # Moderator task — context fences expert output via Moderator Shield
    moderator_task = Task(
        description=build_moderator_prompt(sections, round_number),
        expected_output="Consolidated revision plan resolving expert conflicts",
        agent=mod_agent,
        output_pydantic=ModerationResult,
        context=expert_tasks,  # Waits for all experts
    )

    # Writer task — sees ONLY consolidated_revision_plan (Moderator Shield)
    writer_task = Task(
        description=build_writer_prompt(sections),
        expected_output="Revised section content",
        agent=wrt_agent,
        output_pydantic=WriterRoundOutput,
        context=[moderator_task],  # Never sees raw expert disagreements
    )

    return Crew(
        agents=expert_agents + [mod_agent, wrt_agent],
        tasks=expert_tasks + [moderator_task, writer_task],
        process=Process.sequential,
        verbose=False,
    )
```

### 6.3 CrewAI LangGraph Adapter Node

```python
# pipeline/graph.py (excerpt)
"""
The adapter node bridges LangGraph state to a CrewAI crew round.
"""
from pipeline.interview.crews import build_round_crew


def crewai_refinement_node(state: PipelineState) -> dict:
    """
    Thin adapter: reads from state, runs one crew round, returns state delta.

    Each node is a plain function that bridges LangGraph ↔ CrewAI.
    The node returns ONLY its own state contribution; Annotated
    reducers handle accumulation across rounds.
    """
    sections = state.get("sections", [])
    research_summary = state.get("research_summary", "")

    crew = build_round_crew(
        sections=sections,
        research_summary=research_summary,
        round_number=state.get("current_round", 1),
        latest_rationale=state.get("latest_rationale", ""),
    )

    try:
        result = crew.kickoff()

        # Access structured output via result.pydantic
        writer_output = result.pydantic

        return {
            "sections_optimized": [s.model_dump(mode="json") for s in writer_output.revised_sections],
            "cumulative_tokens": result.token_usage.total_tokens if result.token_usage else 0,
            "phase_token_usage": {"refinement": result.token_usage.total_tokens if result.token_usage else 0},
        }

    except Exception as e:
        # Graceful fallback — return unoptimized sections
        return {
            "sections_optimized": sections,
            "last_error": f"CrewAI execution failed: {e}",
        }
```

---

## 7. The Validation Loop Pattern

### 7.1 Validator Node Topology

**Critical Design**: Separate generation and validation into distinct nodes.

```python
# src/nodes/validators.py
"""
Validation Nodes - The "Immune System" of the agentic workflow.

This module implements the Validator Node Topology:
1. Generator Node produces output
2. Validator Node attempts to parse into Pydantic
3. Router decides: success, retry, or fatal
4. Fixer Node provides correction guidance if retry
"""
from typing import Literal
from pydantic import ValidationError

from pipeline.state import PipelineState
from pipeline.schemas import ResearchArtifact, TaskResult, CrewOutput


def validator_node(state: PipelineState) -> dict:
    """
    Validates all outputs from the previous node.
    
    This node:
    1. Identifies which type of output to validate
    2. Attempts Pydantic validation
    3. Returns validation status for routing
    
    IMPORTANT: Modern LLM "Structured Output" modes guarantee JSON syntax
    but NOT semantic validity against Pydantic constraints.
    Client-side validation is MANDATORY.
    """
    
    current_step = state.get("current_step", "unknown")
    validation_errors = []
    
    # === VALIDATE BASED ON CURRENT STEP ===
    
    if current_step == "research":
        # Validate artifacts
        raw_artifacts = state.get("artifacts", [])
        for i, raw in enumerate(raw_artifacts[-1:]):  # Only validate latest
            if isinstance(raw, dict):
                try:
                    ResearchArtifact.model_validate(raw)
                except ValidationError as e:
                    validation_errors.append(
                        f"Artifact {i} validation failed: {_format_validation_error(e)}"
                    )
    
    elif current_step == "analyzer":
        # Validate task results
        raw_results = state.get("task_results", [])
        for i, raw in enumerate(raw_results[-1:]):
            if isinstance(raw, dict):
                try:
                    TaskResult.model_validate(raw)
                except ValidationError as e:
                    validation_errors.append(
                        f"TaskResult {i} validation failed: {_format_validation_error(e)}"
                    )
    
    elif current_step == "content_crew":
        # Validate crew outputs
        raw_outputs = state.get("crew_outputs", [])
        for i, raw in enumerate(raw_outputs[-1:]):
            if isinstance(raw, dict):
                try:
                    CrewOutput.model_validate(raw)
                except ValidationError as e:
                    validation_errors.append(
                        f"CrewOutput {i} validation failed: {_format_validation_error(e)}"
                    )
    
    # === RETURN VALIDATION STATUS ===
    if validation_errors:
        return {
            "last_error": "\n".join(validation_errors),
            "retry_count": state.get("retry_count", 0) + 1,
        }
    
    return {
        "last_error": None,
        # Don't reset retry_count here - only on successful completion
    }


def _format_validation_error(e: ValidationError) -> str:
    """
    Formats Pydantic ValidationError for LLM consumption.
    
    Provides granular feedback like:
    "The first dependency of the third task is invalid"
    
    This specificity drastically reduces retry cycles.
    """
    error_messages = []
    for error in e.errors():
        loc = " -> ".join(str(l) for l in error["loc"])
        msg = error["msg"]
        error_messages.append(f"  • {loc}: {msg}")
    return "\n".join(error_messages)


def fixer_node(state: PipelineState) -> dict:
    """
    Provides correction guidance for failed validations.

    Stores the correction prompt in state so the re-invoked
    agent can use it. No LangChain message dependency needed.
    """
    error = state.get("last_error", "Unknown validation error")
    current_step = state.get("current_step", "unknown")

    correction_prompt = f"""Your previous response failed validation:

{error}

Regenerate your response, correcting ONLY these specific issues.
- All required fields must be present
- Numeric constraints (ge, le, gt, lt) must be respected
- String patterns must match exactly
"""

    return {
        "correction_prompt": correction_prompt,
        "current_step": current_step,
    }
```

### 7.2 Handling Nested Validation Errors

```python
# src/utils/validation_helpers.py
"""
Advanced validation utilities for nested structures.
"""
from pydantic import ValidationError
from typing import Any


def get_granular_error_path(error: ValidationError) -> list[str]:
    """
    Extracts human-readable paths from nested validation errors.
    
    Example:
        Input: loc=('tasks', 2, 'dependencies', 0)
        Output: "The first dependency of the third task"
    """
    messages = []
    
    for err in error.errors():
        path_parts = []
        loc = err["loc"]
        
        for i, part in enumerate(loc):
            if isinstance(part, int):
                # Convert index to ordinal
                ordinal = _to_ordinal(part + 1)
                if i > 0 and isinstance(loc[i-1], str):
                    path_parts.append(f"the {ordinal} {loc[i-1][:-1] if loc[i-1].endswith('s') else loc[i-1]}")
                else:
                    path_parts.append(f"item {part}")
            else:
                if i == len(loc) - 1:
                    path_parts.append(f"field '{part}'")
        
        path_str = " in ".join(reversed(path_parts))
        messages.append(f"{path_str}: {err['msg']}")
    
    return messages


def _to_ordinal(n: int) -> str:
    """Convert integer to ordinal string."""
    if 10 <= n % 100 <= 20:
        suffix = 'th'
    else:
        suffix = {1: 'st', 2: 'nd', 3: 'rd'}.get(n % 10, 'th')
    return f"{n}{suffix}"
```

### 7.3 Soft + Hard Enforcement Pattern (CRITICAL)

LLMs sometimes ignore prompt constraints (word counts, format rules, etc.). Use **dual-layer enforcement**:

1. **Soft enforcement (prompt)** — include the constraint in the prompt. This works most of the time.
2. **Hard enforcement (code)** — validate after the LLM response. Discard or retry on violation.

```python
# pipeline/interview/loop.py (excerpt)
"""
Example: Word count enforcement on writer revisions.
The prompt asks for ≤10% change; code rejects violations.
"""

def _apply_revisions(
    sections: list[dict],
    writer_output: WriterRoundOutput,
    tolerance: float = 0.10,  # 10% max change
) -> list[dict]:
    """Apply writer revisions with hard word-count enforcement."""
    updated = []
    for section in sections:
        revised = next(
            (r for r in writer_output.revised_sections if r.section_id == section["id"]),
            None,
        )
        if revised is None:
            updated.append(section)
            continue

        # Hard enforcement — code, not LLM
        original_count = len(section["original_text"].split())
        revised_count = len(revised.revised_content.split())
        delta = abs(revised_count - original_count) / max(original_count, 1)

        if delta > tolerance:
            logger.warning(
                "Section %s: word count delta %.0f%% exceeds tolerance %.0f%%, discarding revision",
                section["id"], delta * 100, tolerance * 100,
            )
            updated.append(section)  # Keep original
            continue

        # Revision accepted
        updated.append({**section, "original_text": revised.revised_content})

    return updated
```

**Apply this pattern to ANY LLM output constraint** — character limits, format rules, prohibited content, schema adherence. The prompt gets it right 90% of the time; the code catches the rest.

---

## 8. Serialization and Persistence

### 8.1 The Inflate/Deflate Pattern (CRITICAL)

```python
# src/utils/serialization.py
"""
Serialization utilities implementing the Inflate/Deflate pattern.

PROBLEM: LangGraph's persistence layer serializes state to JSON.
When a Pydantic model containing UUID/datetime is serialized,
these become strings. Upon deserialization, they remain strings,
causing validation failures.

SOLUTION: Explicitly deflate to JSON-safe types before yielding,
and inflate back to Pydantic at node entry.
"""
from typing import TypeVar, Type, Optional, Union
from uuid import UUID
from datetime import datetime
from pydantic import BaseModel

T = TypeVar('T', bound=BaseModel)


def deflate_model(model: BaseModel) -> dict:
    """
    Converts a Pydantic model to a JSON-safe dictionary.
    
    CRITICAL: Always use mode='json' to ensure UUID, datetime, etc.
    are converted to their string representations.
    
    Usage:
        return {"artifact": deflate_model(my_artifact)}
    """
    return model.model_dump(mode='json')


def inflate_model(
    data: Union[dict, BaseModel, None],
    model_class: Type[T]
) -> Optional[T]:
    """
    Reconstructs a Pydantic model from a dictionary.
    
    Handles three cases:
    1. data is None -> returns None
    2. data is already the model type -> returns as-is
    3. data is a dict -> validates and returns model instance
    
    Usage:
        artifact = inflate_model(state.get("artifact"), ResearchArtifact)
    """
    if data is None:
        return None
    
    if isinstance(data, model_class):
        return data
    
    if isinstance(data, dict):
        return model_class.model_validate(data)
    
    raise TypeError(f"Cannot inflate {type(data)} to {model_class}")


def inflate_model_list(
    data: list[Union[dict, BaseModel]],
    model_class: Type[T]
) -> list[T]:
    """
    Inflates a list of dictionaries to model instances.
    
    Usage:
        artifacts = inflate_model_list(state.get("artifacts", []), ResearchArtifact)
    """
    return [
        inflate_model(item, model_class)
        for item in data
        if item is not None
    ]
```

### 8.2 Secure Checkpointer Configuration

```python
# src/graph/persistence.py
"""
Persistence configuration with security best practices.

SECURITY WARNING: Default serializers may fall back to pickle,
which is a severe RCE vulnerability if checkpoints are accessible
from untrusted sources.
"""
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.checkpoint.postgres import PostgresSaver
from langgraph.checkpoint.serde.jsonplus import JsonPlusSerializer


def create_secure_checkpointer(backend: str = "memory", **kwargs):
    """
    Creates a checkpointer with security hardening.
    
    Args:
        backend: One of "memory", "sqlite", "postgres"
        **kwargs: Backend-specific configuration
    
    Returns:
        Configured checkpointer with pickle disabled
    """
    # CRITICAL: Disable pickle fallback
    strict_serializer = JsonPlusSerializer(pickle_fallback=False)
    
    if backend == "memory":
        return InMemorySaver(serde=strict_serializer)
    
    elif backend == "sqlite":
        conn_string = kwargs.get("conn_string", ":memory:")
        return SqliteSaver.from_conn_string(conn_string, serde=strict_serializer)
    
    elif backend == "postgres":
        conn_string = kwargs.get("conn_string")
        if not conn_string:
            raise ValueError("PostgresSaver requires conn_string")
        return PostgresSaver.from_conn_string(conn_string, serde=strict_serializer)
    
    else:
        raise ValueError(f"Unknown backend: {backend}")


# Example for storing exceptions safely
from pydantic import BaseModel
import traceback


class ErrorSnapshot(BaseModel):
    """
    Safe representation of an exception for persistence.
    
    NEVER store Exception objects directly - they are not JSON serializable
    and would trigger pickle fallback.
    """
    error_type: str
    message: str
    traceback_str: str
    timestamp: str
    
    @classmethod
    def from_exception(cls, e: Exception) -> "ErrorSnapshot":
        from datetime import datetime
        return cls(
            error_type=type(e).__name__,
            message=str(e),
            traceback_str=traceback.format_exc(),
            timestamp=datetime.now().isoformat(),
        )
```

---

## 9. Human-in-the-Loop Patterns
### 9.1 The Pause and Validate Protocol

```python
# src/nodes/human_approval.py
"""
Human-in-the-Loop implementation using LangGraph interrupt.

This demonstrates the "Double Loop" pattern:
- Outer Loop: LangGraph graph execution
- Inner Loop: Python while loop for input validation

The node cannot complete until it receives valid human input.
"""
from typing import Literal, Optional
from pydantic import BaseModel, Field, ValidationError
from langgraph.types import interrupt

from pipeline.state import PipelineState


class HumanFeedback(BaseModel):
    """
    Validated schema for human input.
    
    The human/frontend MUST provide data matching this schema.
    """
    action: Literal["approve", "reject", "revise"]
    comments: Optional[str] = Field(default=None, max_length=1000)
    revised_content: Optional[str] = Field(default=None)
    
    def model_post_init(self, __context):
        """Validation: revise action requires revised_content."""
        if self.action == "revise" and not self.revised_content:
            raise ValueError("Revision requires revised_content")


def human_approval_node(state: PipelineState) -> dict:
    """
    Node that pauses for human approval and validates input.
    
    CRITICAL: This implements a validation loop that ONLY exits
    when valid HumanFeedback is received.
    
    The interrupt() call:
    1. Saves current state via checkpointer
    2. Returns control to the caller
    3. Resumes here when graph.invoke() is called with Command(resume=payload)
    """
    
    # Prepare context for the human reviewer
    task_results = state.get("task_results", [])
    crew_outputs = state.get("crew_outputs", [])
    
    review_context = {
        "task_results_count": len(task_results),
        "crew_outputs_count": len(crew_outputs),
        "latest_output": task_results[-1] if task_results else crew_outputs[-1] if crew_outputs else None,
    }
    
    # === VALIDATION LOOP ===
    while True:
        # Interrupt and wait for human input
        user_input = interrupt({
            "message": "Human review required",
            "context": review_context,
            "expected_schema": HumanFeedback.model_json_schema(),
        })
        
        # Validate the resume payload
        try:
            feedback = HumanFeedback.model_validate(user_input)
            
            # Valid input received - process and return
            if feedback.action == "approve":
                return {
                    "next_action": "end",  # Proceed to completion
                    "requires_human_approval": False,
                }
            
            elif feedback.action == "reject":
                return {
                    "next_action": "end",  # Abort workflow
                    "last_error": f"Human rejected: {feedback.comments}",
                    "requires_human_approval": False,
                }
            
            elif feedback.action == "revise":
                # Human provided revised content — inject into conversational state
                # (Only applicable if using ConversationalState with messages field)
                return {
                    "revised_content": feedback.revised_content,
                    "next_action": "router",  # Re-route with new content
                    "requires_human_approval": False,
                }
        
        except ValidationError as e:
            # Invalid input - log and loop again
            print(f"Invalid human feedback: {e}")
            # The interrupt will be called again, waiting for valid input
            continue


# === RESUMING THE GRAPH ===
"""
To resume a graph paused at human_approval_node:

from langgraph.types import Command

# Get the paused graph
config = {"configurable": {"thread_id": "my-thread"}}

# Resume with valid feedback
app.invoke(
    Command(resume={"action": "approve", "comments": "Looks good!"}),
    config=config
)
"""
```

### 9.2 Time Travel and State Editing

```python
# src/utils/state_editing.py
"""
Utilities for safe state editing (Time Travel).

WARNING: Manual state edits can corrupt the schema.
Always validate before submitting to update_state().
"""
from typing import Any
from pydantic import ValidationError

from pipeline.state import PipelineState
from pipeline.schemas import ResearchArtifact, TaskResult, CrewOutput


def validate_state_edit(proposed_state: dict) -> tuple[bool, str]:
    """
    Validates a proposed state edit before applying.
    
    Usage in a UI backend:
        is_valid, error = validate_state_edit(user_proposed_changes)
        if not is_valid:
            return {"error": error}
        app.update_state(config, proposed_state)
    """
    errors = []
    
    # Validate artifacts
    for i, artifact in enumerate(proposed_state.get("artifacts", [])):
        if isinstance(artifact, dict):
            try:
                ResearchArtifact.model_validate(artifact)
            except ValidationError as e:
                errors.append(f"Artifact {i}: {e}")
    
    # Validate task results
    for i, result in enumerate(proposed_state.get("task_results", [])):
        if isinstance(result, dict):
            try:
                TaskResult.model_validate(result)
            except ValidationError as e:
                errors.append(f"TaskResult {i}: {e}")
    
    # Validate crew outputs
    for i, output in enumerate(proposed_state.get("crew_outputs", [])):
        if isinstance(output, dict):
            try:
                CrewOutput.model_validate(output)
            except ValidationError as e:
                errors.append(f"CrewOutput {i}: {e}")
    
    if errors:
        return False, "\n".join(errors)
    
    return True, ""
```

---

## 10. LangGraph Subgraph Pattern

### 10.1 When to Use Subgraphs

Use a **subgraph** (a `StateGraph` compiled and invoked inside a parent node) when a portion of your workflow has:
- Its own iteration loop (e.g., multi-round refinement)
- Different state shape than the parent graph
- Complex internal routing that would clutter the parent topology

The parent graph treats the subgraph as a single node — it sends input and receives output, without knowing the internal structure.

### 10.2 Subgraph State

The subgraph defines its own `TypedDict`, independent of the parent. The parent node is responsible for mapping between the two.

```python
# src/nodes/refinement/state.py
"""
Subgraph state for iterative refinement.
Separate from the parent CVPipelineState.
"""
from typing import Annotated, Optional
from typing_extensions import TypedDict
import operator


class RefinementState(TypedDict, total=False):
    """State for the refinement subgraph."""

    # Input (set once by parent)
    sections: list[dict]          # Sections to refine
    original_texts: dict          # Pre-optimization snapshots

    # Iteration tracking
    current_round: int
    max_rounds: int
    diminishing_returns: bool     # Convergence signal

    # Accumulation (reducers for parallel writes)
    total_tokens: Annotated[int, operator.add]
    round_traces: Annotated[list[dict], operator.add]

    # Output (read by parent after completion)
    optimized_sections: list[dict]
    latest_rationale: Optional[str]
```

### 10.3 Subgraph Definition

```python
# src/nodes/refinement/graph.py
"""
The refinement subgraph: runs multi-round expert review cycles.
"""
from langgraph.graph import StateGraph, END
from .state import RefinementState


def should_continue(state: RefinementState) -> str:
    """Convergence check: stop if max rounds hit or diminishing returns."""
    if state.get("diminishing_returns", False):
        return "done"
    if state.get("current_round", 0) >= state.get("max_rounds", 3):
        return "done"
    return "next_round"


def build_refinement_subgraph():
    """
    Creates the refinement subgraph.

    Topology:
        [run_round] ──► [check_convergence] ──┬──► [run_round]  (loop)
                                               └──► END
    """
    sg = StateGraph(RefinementState)

    sg.add_node("run_round", run_refinement_round)
    sg.set_entry_point("run_round")

    sg.add_conditional_edges(
        "run_round",
        should_continue,
        {"next_round": "run_round", "done": END},
    )

    return sg.compile()


# Module-level singleton
refinement_subgraph = build_refinement_subgraph()
```

### 10.4 Invoking from the Parent Graph

```python
# src/nodes/refinement_adapter.py
"""
Parent-graph node that invokes the refinement subgraph.
Handles state mapping between parent and subgraph.
"""
from pipeline.state import PipelineState
from pipeline.interview.graph import refinement_subgraph
from pipeline.interview.state import RefinementState


def iterative_refine_node(state: PipelineState, config) -> dict:
    """
    Adapts parent state → subgraph state, runs subgraph,
    maps subgraph output → parent state delta.

    IMPORTANT: Forward the RunnableConfig so tracing context
    (Langfuse session, callbacks) propagates into the subgraph.
    """
    # === MAP PARENT → SUBGRAPH STATE ===
    subgraph_input = RefinementState(
        sections=state.get("unified_sections", []),
        original_texts=state.get("original_texts", {}),
        current_round=0,
        max_rounds=3,
        diminishing_returns=False,
        total_tokens=0,
        round_traces=[],
        optimized_sections=[],
        latest_rationale=None,
    )

    try:
        # Forward config for tracing propagation
        result = refinement_subgraph.invoke(subgraph_input, config=config)

        # === MAP SUBGRAPH OUTPUT → PARENT STATE DELTA ===
        return {
            "optimized_sections": result.get("optimized_sections", []),
            "cumulative_tokens": result.get("total_tokens", 0),
            "phase_token_usage": {"refinement": result.get("total_tokens", 0)},
        }

    except Exception as e:
        # Graceful fallback: return unoptimized sections
        return {
            "optimized_sections": state.get("unified_sections", []),
            "last_error": f"Refinement failed: {e}",
        }
```

---

## 11. Testing Strategies

### 11.1 Unit Testing with TestModel

```python
# tests/unit/test_pydantic_ai_nodes.py
"""
Unit tests for Pydantic AI nodes using TestModel.

TestModel replaces the real LLM with a deterministic simulator,
allowing testing of node logic without network calls or costs.
"""
import pytest
from pydantic_ai.models.test import TestModel
from uuid import uuid4

from pipeline.research import (
    research_agent,
    pydantic_ai_research_node,
    ResearchOutput,
)
from pipeline.state import create_initial_state


@pytest.mark.asyncio
async def test_research_node_produces_valid_artifact():
    """
    Tests that the research node produces structurally valid output.
    
    Note: We test STRUCTURE, not content (which is non-deterministic).
    """
    # Setup mock state
    state = create_initial_state("Research AI safety best practices")
    
    # Create deterministic mock output
    mock_output = ResearchOutput(
        findings=["Finding 1: AI safety is important", "Finding 2: Testing is crucial"],
        sources=["https://example.com/source1"],
        confidence=0.85,
        suggested_followup="Investigate alignment techniques",
    )
    
    # Override agent's model with TestModel
    mock_model = TestModel(
        custom_result_args=mock_output.model_dump()
    )
    
    with research_agent.override(model=mock_model):
        result = await pydantic_ai_research_node(state)
    
    # Assert structure
    assert "artifacts" in result
    assert len(result["artifacts"]) == 1
    assert result["last_error"] is None
    
    # Validate the artifact can be parsed
    from pipeline.schemas import ResearchArtifact
    artifact = ResearchArtifact.model_validate(result["artifacts"][0])
    assert artifact.relevance_score == 0.85


@pytest.mark.asyncio
async def test_research_node_handles_llm_error():
    """Tests that the node gracefully handles LLM failures."""
    state = create_initial_state("Test query")
    
    # Create a TestModel that raises an error
    mock_model = TestModel(custom_result_text="invalid json{{{")
    
    with research_agent.override(model=mock_model):
        result = await pydantic_ai_research_node(state)
    
    # Should capture error without crashing
    assert result.get("last_error") is not None
    assert result.get("retry_count", 0) > 0
```

### 11.2 Integration Testing with InMemorySaver

```python
# tests/integration/test_full_workflow.py
"""
Integration tests for the complete graph workflow.
"""
import pytest
from langgraph.checkpoint.memory import InMemorySaver

from pipeline.graph import compile_graph
from pipeline.state import create_initial_state


@pytest.fixture
def app():
    """Creates a compiled graph with in-memory persistence."""
    return compile_graph(use_persistence=True)


def test_full_workflow_completes(app):
    """Tests that a simple workflow runs to completion."""
    initial_state = create_initial_state(
        "Write a brief analysis of renewable energy trends"
    )
    
    config = {"configurable": {"thread_id": "test-thread-1"}}
    
    # Run the graph
    result = app.invoke(initial_state, config=config)
    
    # Assert completion
    assert result.get("next_action") == "end" or result.get("last_error") is None


def test_workflow_persists_state(app):
    """Tests that state is persisted and recoverable."""
    initial_state = create_initial_state("Test persistence")
    config = {"configurable": {"thread_id": "test-thread-2"}}
    
    # Run graph
    app.invoke(initial_state, config=config)
    
    # Retrieve persisted state
    snapshot = app.get_state(config)
    
    assert snapshot is not None
    assert len(snapshot.values.get("messages", [])) > 0


def test_workflow_handles_retry(app):
    """Tests the retry loop on validation failure."""
    # This test would require mocking to inject a validation failure
    # Demonstrating the pattern:
    pass
```

### 11.3 Snapshot Testing

```python
# tests/unit/test_state_snapshots.py
"""
Snapshot testing for complex state objects.
"""
import pytest
from dirty_equals import IsInt, IsStr, IsNow, IsUUID

from pipeline.state import create_initial_state


def test_initial_state_structure():
    """Verifies initial state matches expected structure."""
    state = create_initial_state("Test message")
    
    # Use dirty_equals for flexible matching
    assert state == {
        "messages": [{"content": "Test message", "type": IsStr()}],  # Simplified
        "artifacts": [],
        "task_results": [],
        "crew_outputs": [],
        "memory": None,
        "current_step": "entry",
        "retry_count": 0,
        "max_retries": 3,
        "last_error": None,
        "next_action": None,
        "requires_human_approval": False,
    }
```

---

## 12. Observability and Production Engineering

### 12.1 Unified Distributed Tracing

The key insight is that **all three frameworks support OpenTelemetry**. Configure OTel once, then plug in any backend (Langfuse, LangSmith, Jaeger, Datadog).

```python
# src/observability/tracing.py
"""
Unified tracing for LangGraph + Pydantic AI + CrewAI.

PROBLEM: Each framework emits its own traces — they appear as
separate operations without context propagation.

SOLUTION: All three frameworks bridge to OpenTelemetry.
Configure OTel once, instrument all frameworks, then export
to whichever backend you use (Langfuse, LangSmith, Jaeger, etc.).

CRITICAL: Call init_tracing() once at application startup, before
any agent runs. The @lru_cache ensures idempotency.
"""
import logging
from functools import lru_cache

from django.conf import settings  # Or your config system
from pydantic_ai import Agent
from openinference.instrumentation.crewai import CrewAIInstrumentor

logger = logging.getLogger(__name__)


@lru_cache(maxsize=1)
def init_tracing() -> bool:
    """Idempotent tracing setup. Call once at pipeline entry point.

    Returns True if tracing was enabled, False if credentials are missing.
    """
    # --- Backend setup (pick ONE) ---

    # Option A: Langfuse (recommended — open-source, self-hostable)
    # Requires: LANGFUSE_SECRET_KEY, LANGFUSE_PUBLIC_KEY env vars
    if not settings.LANGFUSE_PUBLIC_KEY or not settings.LANGFUSE_SECRET_KEY:
        logger.info("Tracing credentials not set — tracing disabled")
        return False

    from langfuse import get_client
    get_client()  # Initializes singleton, auto-registers OTel exporter

    # Option B: LangSmith
    # from langsmith.integrations.otel import configure as configure_langsmith
    # configure_langsmith(project_name="production")

    # Option C: Generic OTLP (Jaeger, Datadog, etc.)
    # from opentelemetry.sdk.trace import TracerProvider
    # from opentelemetry.sdk.trace.export import BatchSpanProcessor
    # from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
    # from opentelemetry import trace
    # provider = TracerProvider()
    # provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter()))
    # trace.set_tracer_provider(provider)

    # --- Framework instrumentation (always do both) ---
    Agent.instrument_all()                          # Pydantic AI → OTel spans
    CrewAIInstrumentor().instrument(skip_dep_check=True)  # CrewAI → OTel spans

    logger.info("Tracing initialized (Pydantic AI + CrewAI)")
    return True


def get_tracing_callback():
    """Return a tracing CallbackHandler for LangGraph, or None if disabled.

    Must be called INSIDE a propagate_attributes() context so the handler
    inherits session_id and other trace attributes automatically.
    """
    if not settings.LANGFUSE_PUBLIC_KEY or not settings.LANGFUSE_SECRET_KEY:
        return None

    from langfuse.langchain import CallbackHandler
    return CallbackHandler()
```

#### 12.1.1 The Three-Mechanism Integration

Each framework bridges to OTel differently. Understanding this is critical for debugging trace gaps:

| Framework | Mechanism | How spans reach your backend |
|-|-|-|
| Pydantic AI | `Agent.instrument_all()` | OTel auto-instruments all `.run()` / `.run_sync()` calls. No per-agent wiring needed. |
| CrewAI | `CrewAIInstrumentor().instrument()` | OpenInference wraps CrewAI's LLM calls → emits OTel spans → your exporter picks them up. |
| LangGraph | Callback handler | Your tracing backend's LangChain `CallbackHandler` is passed to `graph.invoke(config={"callbacks": [handler]})`. |

**Why LangGraph is different:** LangGraph uses LangChain's callback system, not OTel directly. You must create a callback handler from your tracing backend and pass it explicitly to `graph.invoke()`.

#### 12.1.2 Session Binding and Root Span

To group all spans (across all three frameworks) under a single trace/session:

```python
# src/graph/orchestrator.py
"""
Orchestrator showing the full tracing integration pattern.

Three things must happen inside the same context:
1. A root span wraps the entire pipeline run
2. propagate_attributes() sets session_id so Pydantic AI + CrewAI inherit it
3. A CallbackHandler is created INSIDE the context so it inherits the session
"""
from pipeline.tracing import init_tracing


def run_pipeline(graph, initial_state, session_id: str, tags: list[str] = None):
    """Run the graph with unified tracing context."""
    init_tracing()

    # Import from your tracing backend
    # Langfuse example shown; adapt for LangSmith or other backends.
    from langfuse import get_client, propagate_attributes
    from langfuse.langchain import CallbackHandler

    langfuse = get_client()
    tags = tags or []

    # Root span wraps the entire pipeline execution
    with langfuse.start_as_current_observation(as_type="span", name="pipeline-run") as root_span:
        # propagate_attributes sets OTel context variables that
        # Pydantic AI + CrewAI spans automatically inherit.
        with propagate_attributes(session_id=session_id, tags=tags):
            # CRITICAL: Create the callback handler INSIDE the context
            # so it inherits the session_id automatically.
            langfuse_handler = CallbackHandler()

            result = graph.invoke(
                initial_state,
                config={"callbacks": [langfuse_handler]},
            )

            # Enrich root span with pipeline results
            root_span.update(
                name=result.get("trace_name", "pipeline-run"),
                input={"session_id": session_id},
                output={"tokens": result.get("cumulative_tokens", 0)},
            )

    return result
```

**Key rules:**
- `init_tracing()` is called once (idempotent). It instruments Pydantic AI + CrewAI globally.
- `propagate_attributes()` context must wrap both the callback handler creation AND the `graph.invoke()` call.
- The callback handler must be created **inside** the `propagate_attributes` context — otherwise it won't inherit the session.
- **Result:** All LLM calls — research agents, interview crews, graph orchestration — appear under one session in your tracing dashboard.

### 12.2 Semantic Metrics

```python
# src/observability/metrics.py
"""
Custom metrics for agentic system health monitoring.
"""
from dataclasses import dataclass
from typing import Optional
from datetime import datetime


@dataclass
class AgentMetrics:
    """Tracks key performance indicators."""
    
    # Validation metrics
    validation_attempts: int = 0
    validation_failures: int = 0
    
    # Retry metrics
    total_retries: int = 0
    max_retry_depth: int = 0
    
    # Timing metrics
    avg_node_latency_ms: float = 0.0
    total_execution_time_ms: float = 0.0
    
    @property
    def validation_failure_rate(self) -> float:
        """Percentage of LLM responses that fail Pydantic validation."""
        if self.validation_attempts == 0:
            return 0.0
        return self.validation_failures / self.validation_attempts
    
    @property
    def avg_retry_depth(self) -> float:
        """Average loops required for valid response."""
        if self.validation_attempts == 0:
            return 0.0
        return self.total_retries / self.validation_attempts


def log_validation_event(
    success: bool,
    retry_count: int,
    node_name: str,
    latency_ms: float,
):
    """
    Logs validation events for monitoring.
    
    Alert thresholds:
    - validation_failure_rate > 0.3 → Model drift warning
    - avg_retry_depth > 1.5 → Cost efficiency degradation
    """
    # In production, send to your metrics backend
    # (Prometheus, Datadog, CloudWatch, etc.)
    pass
```

### 12.3 Security Best Practices

```python
# src/security/sanitization.py
"""
Security utilities for input/output sanitization.

Pydantic is your PRIMARY security firewall.
"""
from pydantic import BaseModel, Field, field_validator
import re


class SanitizedUserInput(BaseModel):
    """
    Validates and sanitizes user input before processing.
    
    NEVER pass raw user input to tools or LLM prompts.
    """
    content: str = Field(..., min_length=1, max_length=10000)
    
    @field_validator('content')
    @classmethod
    def sanitize_content(cls, v: str) -> str:
        # Strip whitespace
        v = v.strip()
        
        # Remove potential prompt injection patterns
        # (This is defense in depth - not a complete solution)
        dangerous_patterns = [
            r'ignore\s+previous\s+instructions',
            r'disregard\s+all\s+prior',
            r'system\s*:\s*',
        ]
        
        for pattern in dangerous_patterns:
            v = re.sub(pattern, '[FILTERED]', v, flags=re.IGNORECASE)
        
        return v


class CodeExecutionRequest(BaseModel):
    """
    Validates code execution requests against an allowlist.
    
    NEVER blindly execute LLM-generated code.
    """
    command: str
    arguments: list[str] = Field(default_factory=list)
    
    # Allowlist of safe commands
    ALLOWED_COMMANDS = {'ls', 'cat', 'echo', 'grep', 'find'}
    
    @field_validator('command')
    @classmethod
    def validate_command(cls, v: str) -> str:
        if v not in cls.ALLOWED_COMMANDS:
            raise ValueError(f"Command '{v}' not in allowlist")
        return v
```

---

## 13. Complete Reference Implementation

### 13.1 Main Entry Point

```python
# main.py
"""
Main entry point for the agentic system.
"""
import asyncio
from pipeline.graph import compile_graph
from pipeline.state import create_initial_state
from pipeline.tracing import init_tracing


async def main():
    # Setup observability (idempotent, safe to call multiple times)
    init_tracing()
    
    # Compile the graph
    app = compile_graph(use_persistence=True)
    
    # Create initial state
    initial_state = create_initial_state(
        user_message="Create a comprehensive analysis of AI agent frameworks, "
                     "comparing LangGraph, Pydantic AI, and CrewAI. "
                     "Include code examples and best practices."
    )
    
    # Run the graph
    config = {"configurable": {"thread_id": "demo-thread-001"}}
    
    print("Starting agentic workflow...")
    
    # Stream events for visibility
    async for event in app.astream_events(initial_state, config=config, version="v2"):
        kind = event["event"]
        
        if kind == "on_chain_start":
            print(f"\n→ Starting: {event['name']}")
        elif kind == "on_chain_end":
            print(f"✓ Completed: {event['name']}")
        elif kind == "on_tool_start":
            print(f"  🔧 Tool: {event['name']}")
    
    # Get final state
    final_state = app.get_state(config)
    
    print("\n" + "="*50)
    print("WORKFLOW COMPLETE")
    print("="*50)
    print(f"Artifacts collected: {len(final_state.values.get('artifacts', []))}")
    print(f"Tasks completed: {len(final_state.values.get('task_results', []))}")
    print(f"Crew outputs: {len(final_state.values.get('crew_outputs', []))}")
    
    # Print final output
    if final_state.values.get("task_results"):
        latest = final_state.values["task_results"][-1]
        print(f"\nLatest output:\n{latest.get('output', 'N/A')[:500]}...")


if __name__ == "__main__":
    asyncio.run(main())
```

### 13.2 Docker Configuration

```dockerfile
# Dockerfile
FROM python:3.11-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    build-essential \
    && rm -rf /var/lib/apt/lists/*

# Install Python dependencies
COPY pyproject.toml .
RUN pip install --no-cache-dir .

# Copy application code
COPY src/ src/
COPY main.py .

# Set environment variables
ENV PYTHONUNBUFFERED=1
ENV PYTHONDONTWRITEBYTECODE=1

CMD ["python", "main.py"]
```

---

## 14. Anti-Patterns and Common Pitfalls

### 14.1 Common Mistakes

| Anti-Pattern | Problem | Solution |
|-|-|-|
| Hardcoding model in `Agent('openai:gpt-4o', ...)` | Can't swap models per environment or test | Use model factory; pass model at `.run()` time |
| Using `TypedDict` for complex values | No runtime validation | Use Pydantic models for domain objects |
| Storing `Exception` objects in state | Pickle fallback, security risk | Store `ErrorSnapshot` Pydantic model |
| Validating inside generator node | Conflated concerns, harder to debug | Separate Validator Node Topology |
| Trusting LLM "Structured Output" | Only guarantees JSON syntax, not semantics | Always validate client-side with Pydantic |
| Forgetting `mode='json'` in `model_dump()` | UUID/datetime serialization breaks checkpoints | Always use `model_dump(mode='json')` |
| Manual pickle serialization | Security vulnerability (RCE) | Use `JsonPlusSerializer(pickle_fallback=False)` |
| No retry limit | Infinite loops on persistent errors | Always set `max_retries` in state |
| Modifying state in place | Graph integrity issues | Return new state dict from nodes |
| Putting iteration logic in parent graph | Clutters parent topology | Use a subgraph with its own state |
| Reusing CrewAI `Crew` or `Agent` objects across rounds | CrewAI mutates internal state during `kickoff()` | Instantiate fresh `Crew` and clone `Agent` per round |
| Prompt-only constraint enforcement | LLMs ignore constraints ~10% of the time | Soft (prompt) + Hard (code) enforcement |
| Shared `CallbackHandler` across threads | Cross-contamination in concurrent environments | Create per-task/request handler |
| Installing Langfuse before CrewAI | OTel resolves to 1.39.x, breaks CrewAI's ~=1.34.0 | Install CrewAI first or use lockfile |
| `langchain-core` alone for Langfuse | `CallbackHandler` does `import langchain` | Install full `langchain>=1.2` |
| Using `LangChain messages` in task pipelines | Unnecessary dependency, adds message overhead | Use pure `TypedDict(total=False)` domain fields |

### 14.2 Performance Considerations

```python
"""
Performance Optimization Guidelines:

1. Minimize State Size
   - Don't store full conversation history indefinitely
   - Summarize/compress older context
   - Use references (IDs) instead of full objects where possible

2. Parallel Execution
   - Use LangGraph's fan-out/fan-in for independent tasks (deterministic, no OTel issues)
   - CrewAI async_execution=True gives parallelism inside a crew, BUT breaks OTel tracing
   - Trade-off: async_execution=True is acceptable when parallelism matters more than
     perfect trace linkage. Output correctness is unaffected — only observability suffers.

3. Caching
   - Cache expensive LLM calls with semantic similarity
   - Use LangGraph's built-in caching where available

4. Batching
   - Batch multiple validation checks in single Pydantic call
   - Batch LLM requests where API supports it

5. Token Tracking
   - Use Annotated reducers (operator.add) for cumulative_tokens across parallel nodes
   - Each node returns ONLY its own delta; LangGraph applies the reducer
   - Track per-phase costs via phase_token_usage dict with _merge_dicts reducer
"""
```

---

## Appendix A: Quick Reference Card

```
LANGGRAPH + PYDANTIC AI + CREWAI — Quick Reference Card

STATE DEFINITION:
  TypedDict(total=False) envelope + Pydantic BaseModel payload
  Task pipeline: pure domain fields, no LangChain messages
  Conversational: add messages: Annotated[list[BaseMessage], operator.add]

SERIALIZATION:
  Deflate: model.model_dump(mode='json')
  Inflate: ModelClass.model_validate(data)

SECURITY:
  JsonPlusSerializer(pickle_fallback=False)

MODEL INJECTION:
  Agent defined WITHOUT model → model passed at .run(model=get_model("tier"))
  Never hardcode model identifiers in Agent constructors

NODE TYPES:
  Standard:    def node(state: PipelineState) -> dict
  Pydantic AI: Wrap agent.run(model=...) in adapter function
  CrewAI:      Fresh Crew per round → crew.kickoff() → result.pydantic
  Subgraph:    compiled StateGraph invoked inside a parent node
  Handler:     BaseHandler.extract() → graph → handler.apply()

CREWAI RULES:
  AgentTemplate (frozen dataclass) → _clone_agent() per round
  Never reuse Crew or Agent across iterations (they mutate)
  output_pydantic= on Task enforces structured output

VALIDATION LOOP:
  Generator → Validator → Router → Fixer (if error) → Generator

HUMAN-IN-THE-LOOP:
  interrupt(payload) + while True validation loop

TESTING:
  Unit: pydantic_ai.models.test.TestModel
  Integration: InMemorySaver
  Snapshot: dirty_equals

TRACING (three mechanisms):
  init_tracing() once at startup (idempotent via @lru_cache)
  Pydantic AI:  Agent.instrument_all()              → OTel auto-instrumentation
  CrewAI:       CrewAIInstrumentor().instrument()    → OpenInference → OTel
  LangGraph:    CallbackHandler passed to graph.invoke(config={"callbacks": [h]})
  Session:      propagate_attributes(session_id=...) groups all spans
  IMPORTANT:    Create CallbackHandler INSIDE propagate_attributes context
```

---

## Appendix B: Version Compatibility

| Component | Minimum Version | Recommended | Notes |
|-|-|-|-|
| Python | 3.11 | 3.12+ | 3.10 has Langfuse+LangGraph issues |
| LangGraph | 1.0.0 | Latest | 1.0 API stability |
| Pydantic | 2.5 | Latest | v2 required for `model_dump(mode='json')`, `ConfigDict` |
| Pydantic AI | 0.1.0 | Latest | Use `pydantic-ai[openrouter]` for OpenRouter setups |
| CrewAI | 1.10.0 | Latest | 1.10+ required for Unified Memory, scoped access |
| langchain | 1.2.0 | Latest | Full `langchain` required for Langfuse `CallbackHandler` |
| Langfuse | 3.0.0 | Latest | v3 = OTel rewrite; v4 removes `update_trace()` from spans |
| openinference-instrumentation-crewai | 0.1.0 | Latest | CrewAI → OTel bridge |

### Dependency Install Order (Critical)

CrewAI pins `opentelemetry-api~=1.34.0` (narrow). If Langfuse installs first, pip resolves OTel to 1.39.x, violating CrewAI's pin. Use a lockfile or install in order:

```bash
pip install crewai        # Pins OTel ~=1.34.0
pip install langfuse      # Accepts >=1.33.1, uses 1.34.x (already installed)
pip install langchain     # Full package (not langchain-core)
pip install pydantic-ai[openrouter]
pip install openinference-instrumentation-crewai
```

---

*This guide represents typical patterns. Implementations should be adapted to specific organizational requirements and security policies.*
